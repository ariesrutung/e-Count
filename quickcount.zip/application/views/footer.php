<!-- Footer-->
<footer class="footer text-center">
    <div class="container px-4 px-lg-5">
        <p class="text-muted small mb-0">Copyright &copy; Hitung Cepat 2024</p>
    </div>
</footer>
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top"><i class="fas fa-angle-up"></i></a>
<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Core theme JS-->
<script src="<?= base_url(); ?>assets/js/scripts.js"></script>
<script>
    $(document).ready(function() {
        $('#tabelSuara').DataTable();
    });
</script>
</body>

</html>